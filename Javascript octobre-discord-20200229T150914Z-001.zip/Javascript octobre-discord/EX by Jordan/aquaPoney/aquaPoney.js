let vmax = 20;
let d;
var delayInMilliseconds = 100; //1 second
var x;
let premier=0;
let position = [];

$('#btn1').click(function(){go()});
$('#btn2').click(function(){clearInterval(x);});


function go(){
	x=setInterval("race()", delayInMilliseconds)
}

function race(){
	console.log('Gooo !!!!!');
	for (var i = 0; i < 4; i++) {
	if (($('.container #'+i+'').css('margin-left')).split('px')[0]>550) {finish()}
	d=Math.trunc(Math.random()*vmax);
	$('.container #'+i+'').css('margin-left','+='+d+'px');
	}




}

function finish(){
	clearInterval(x);
	for(let i=0; i<4;i++){
		position[i] = parseInt(($('.container #'+i+'').css('margin-left')).split('px')[0],10);
	}
	premier = position.indexOf(Math.max(...position));
	$('.container #'+premier+'').css('margin-left',0).css('width','500px').hide().show(5000)



}