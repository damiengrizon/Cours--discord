function validation(){
    let nom = $('#nom').val().trim();
    let prenom = $('#prenom').val().trim();
    let age = $('#age').val();
    let pays = $('#pays').val();

    let nbFruit = $('input[name="fruit[]"]:checked').length;
    //let nbFruit = $('.my-fruit:checked').length;
    //ds le html :<input class="my-fruit" ....
    //let genre = $('input[name="genre"]:cheked').val();
    let genre = $('.my-genre:checked').val();
    // ds le html :<input 
    console.log(nom);
    console.log(prenom);
    console.log(age);
    console.log(pays);
    console.log(nbFruit);
    console.log(genre);
    if (nom.length ==0){
        alert ('nom ????');
        return false;
    }else if (prenom.length == 0){
        alert ('prenom ????');
        return false;        
    }
}