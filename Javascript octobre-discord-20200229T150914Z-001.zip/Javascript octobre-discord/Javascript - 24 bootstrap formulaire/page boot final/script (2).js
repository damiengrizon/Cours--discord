function validation(){
	$('input').removeClass('rouge');
	$('.alert').removeClass('show');
	let nom = $('#nom').val().trim();
	let prenom = $('#prenom').val().trim();
	let age = $('#age').val();
	let pays = $('#pays').val();

	let nbFruit = $('input[name="fruit[]"]:checked').length;
	//let nbFruit = $('.my-fruit:checked').length;
	//ds le html :<input class="my-fruit" ....
	//let genre = $('input[name="genre"]:cheked').val();
	let genre = $('.my-genre:checked').val();
	// ds le html :<input 
	console.log(nom);
	console.log(prenom);
	console.log(age);
	console.log(pays);
	console.log(nbFruit);
	console.log(genre);
	let test = true;
	if (nom.length ==0){
		$('.alert').addClass('show').append('Veuillez saisir votre nom.');
		$('#nom').addClass('rouge');
		test= false;
	}
	 if (prenom.length == 0){
		$('.alert').addClass('show').append('<br>Veuillez saisir votre prénom.');
		$('#prenom').addClass('rouge');
		test= false;		
	}
	if (age.length == 0){
		$('#age').addClass('rouge');
		$('.alert').addClass('show').append('<br>Veuillez saisir votre age.');
		test= false;		
	}
	if (age < 18){
		$('#age').addClass('rouge');
		$('.alert').addClass('show').append('<br>Interdit au moins de 18 ans.');
		test= false;		
	}
	if (pays == 'al'){
		$('#pays').addClass('rouge');
		$('.alert').addClass('show').append('<br>Interdit aux Allemands.');
		test= false;		
	}
	if (nbFruit < 3){
		$('.alert').addClass('show').append('<br>3 Fruits minimum.');
		test= false;		
	}
	if (genre == 'alien'){
		$('.alert').addClass('show').append('<br>Interdit aux aliens.');
		test= false;		
	}
	if ( test == false){
		return test;
	}
}