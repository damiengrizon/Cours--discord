function calcul(){
    // je viens recupérer les infos saisies
    var poids = document.getElementById('poids').value;
    var taille = document.getElementById('taille').value;
    // je vide les champs de saisie
    document.getElementById('poids').value = '';
    document.getElementById('taille').value = '';
    // calcul imc
    var imc = poids / (taille * taille);
    imc = Math.round(imc *10)/10;
    // j affiche le resultat
    document.getElementById('info').innerHTML = 'Votre imc:'+imc;
    var str ='';
    if (imc < 18.5){
        str = 'maigreur';
    }else if (imc < 25){
        str = 'normal';
    }else{
        str ='surpoids';
    }
    document.getElementById('info').innerHTML += '<br>' +str;
}