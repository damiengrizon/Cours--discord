<script>
    let x =42;
    //let str = 'bonjour';
    // stocker ds le localStorage
    //localStorage.clear(); // je vide tout le local storage
    //localStorage.x = x;
    //localStorage.str = str;
    // je test si il y a ds le localStrage
    localStorage.removeItem('str');
    if ( localStorage.x != undefined){
        console.log(localStorage);
    }
    // stocker un tableau
    let tab = [ 'un','deux','trois'];
    let str = JSON.stringify(tab); // je transform mon tableau en chaine de car.
    console.log(str);
    //localStorage.tableau = str;

    // recuperer un tableau
    let str2 = localStorage.tableau;
    let tab2 = JSON.parse(str2); //je transforme une chaine de car. en tab.
    console.log(tab2);
</script>