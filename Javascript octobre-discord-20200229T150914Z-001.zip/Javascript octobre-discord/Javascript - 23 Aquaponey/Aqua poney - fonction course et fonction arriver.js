$('#btn1').click(function(){
    course();
});

let avance =[0,0,0,0];
let tabArrive =[];
function course(){
    $('#btn1').attr('disabled',true);
    setTimeout(function(){
        let nbPoneyArrive = tabArrive.length;
        for (i=0; i< avance.length;i++){
            $('.container').children().eq(i).css('margin-left',avance[i]);
            let alea = Math.floor(Math.random() * 100);
            // si avance[i] + alea >= 600 : je bloque a 600
            if ((avance[i]+alea) >= 550){
                avance[i]=550;
                arriver(i);
            }else{
            // je continue de le faire avancer
                avance[i] +=alea;
            }
        }     

        if ( nbPoneyArrive  < 4){
            course();
        }
         
    }, 50);
}
function arriver(i){
    // je verifie si il n'est pas deja arrive
    test = true;
    for ( let poney of tabArrive){
        if (poney == i){
            test = false;
        }
    }
    if (test){
        tabArrive.push(i);
        console.log('poney '+i);
    }    
}