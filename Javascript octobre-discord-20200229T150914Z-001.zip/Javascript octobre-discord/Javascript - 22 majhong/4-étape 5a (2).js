// etape 3 afficher les tuiles de 0 à 15 2 fois mélangées
function melanger(tab){
    let tab2 =[];
    for(let i =0;i<tab.length;i++){        
        do{
            // je genere un nb alea de 0 à taille du tableau
            x =    Math.floor(Math.random() * tab.length);
        }while(tab2[x] != undefined);
        // tant que l'emplacement n'est pas vide
        tab2[x] = tab[i];
    }
    return tab2;
}
//---------------------------------------------------
var tab = [];
for(let i=0;i<42;i++){
    tab.push(i);
}
tab = melanger(tab);

let tab2 =[];
for(let i=0; i<16;i++){
    tab2[i] = tab [i];
}
//let tab2 = tab.splice(0,16);

tab2 = tab2.concat(tab2) ;// tab = tab + tab

tab2 = melanger(tab2);
// afficher le tableau
for (let tuile of tab2){
    let str ='<div><img src="./images/'
            + tuile 
            + '.jpg" data-num="'+ tuile+'" width="80"></div>';
    $('.container').append(str);

}
//---------------------------------------
$('.container img').click(function(){
    let num = $(this).data('num');
    console.log(num);
});