// etape 2 afficher les tuiles de 0 à 15 2 fois


var tab = [];
for(let i=0;i<16;i++){
    tab.push(i);
}
tab = tab.concat(tab) ;// tab = tab + tab

// afficher le tableau
for (let tuile of tab){
    let str ='<div><img src="./images/'+ tuile + '.jpg" width="80"></div>';
    $('.container').append(str);

}