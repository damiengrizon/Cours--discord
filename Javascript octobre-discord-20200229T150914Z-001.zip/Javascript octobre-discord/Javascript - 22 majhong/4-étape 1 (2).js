// etape afficher les tuiles de 0 à 31
//for(let i=0;i<32;i++){
//    let str ='<div><img src="./images/'+ i + '.jpg" width="80"></div>';
//    $('.container').append(str);
//}
//--------------------------------
// 2eme solution
// je créée le tableau
var tab = [];
for(let i=0;i<32;i++){
    tab[i] = i;
}
// afficher le tableau
for (let tuile of tab){
    let str ='<div><img src="./images/'+ tuile + '.jpg" width="80"></div>';
    $('.container').append(str);

}