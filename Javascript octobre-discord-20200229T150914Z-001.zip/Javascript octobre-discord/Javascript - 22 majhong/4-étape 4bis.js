$('.container img').click(function(){
    $(this).hide();
});